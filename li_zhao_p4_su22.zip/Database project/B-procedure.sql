-- STORED PROCEDURES

-- The data is imported from the accounting books
CREATE OR ALTER PROCEDURE asset_import
@name VARCHAR(50), 
@purchase_date date,
@price DECIMAL(20,4),
@number DECIMAL(20,4)
AS
BEGIN
	DECLARE @assetID DECIMAL(12);
	SELECT @assetID = assetID 
	FROM asset
	WHERE name = @name;
	
	IF @assetID is NULL BEGIN
		SET @assetID = NEXT VALUE FOR asset_seq; 
		INSERT INTO [asset] ([assetID], [producerID], [locationID], [name], [total price], [total number]) 
		VALUES (@assetID, NULL, 1, @name, @price, @number);
		PRINT 'The new asset is inserted';
	END
	ELSE BEGIN
		UPDATE asset SET [total price] = [total price] + @price,[total number] = [total number] + @number
		WHERE assetID = @assetID
		PRINT 'Update the original asset ';
	END
	
	DECLARE @current_accounting_seq DECIMAL(12);
	SET @current_accounting_seq = NEXT VALUE FOR accounting_seq; 
	INSERT INTO [accounting] ([accountingID], [assetID], [name], [purchase date], [price], [number]) 
	VALUES (@current_accounting_seq, @assetID, @name, @purchase_date, @price, @number);
	
END; 
GO

-- When someone is going to use an asset
CREATE OR ALTER PROCEDURE use_asset
@employeeID DECIMAL(12), 
@assetID DECIMAL(12),
@start_date DATE
AS
BEGIN
	DECLARE @is_using_asset DECIMAL(12);
	SELECT @is_using_asset = count(assetID)
	FROM [user]
	WHERE  assetID = @assetID AND
	end_date is NULL
	
	DECLARE @all_relevant_asset DECIMAL(12);
	SELECT @all_relevant_asset = [total number]
	FROM [asset]
	WHERE  assetID = @assetID
	
	IF @is_using_asset = @all_relevant_asset BEGIN
		RAISERROR('The operation fails because all assets of the same name are in use',14,1)
		RETURN
	END
	
	DECLARE @has_permission DECIMAL(12);
	SELECT @has_permission = employeeID
	FROM distribution INNER JOIN permission
	ON distribution.permissionID = permission.permissionID
	WHERE employeeID = @employeeID AND
	description = 'use asset'
	
	IF @has_permission is NULL BEGIN
		RAISERROR('The operation fails because there is no permission to use the asset',14,1)
		RETURN
	END
	
	DECLARE @current_user_seq DECIMAL(12);
	SET @current_user_seq = NEXT VALUE FOR user_seq; 
	INSERT INTO [user] ([userID], [employeeID], [assetID], [start_date], [end_date]) 
	VALUES (@current_user_seq, @employeeID, @assetID, @start_date, NULL);
	
	PRINT 'The operation is successful and the asset is used'
	
END; 
GO
