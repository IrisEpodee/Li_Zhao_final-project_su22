--TABLES
--Replace this with your table creations.

--SEQUENCES
--Replace this with your sequence creations.

--INDEXES
--Replace this with your index creations.

--STORED PROCEDURES
--Replace this with your stored procedure definitions.

--INSERTS
--Replace this with the inserts necessary to populate your tables.
--Some of these inserts will come from executing the stored procedures.

--QUERIES
--Replace this with your queries.