-- INSERTS

-- Insert three permissions for Using, Keeping, Quering, Changing
DECLARE @current_permission_seq DECIMAL(12);
SET @current_permission_seq = NEXT VALUE FOR permission_seq; 
INSERT INTO [permission] ([permissionID], [description]) VALUES (@current_permission_seq, 'use asset');
SET @current_permission_seq = NEXT VALUE FOR permission_seq; 
INSERT INTO [permission] ([permissionID], [description]) VALUES (@current_permission_seq, 'keep asset');
SET @current_permission_seq = NEXT VALUE FOR permission_seq; 
INSERT INTO [permission] ([permissionID], [description]) VALUES (@current_permission_seq, 'query asset');
SET @current_permission_seq = NEXT VALUE FOR permission_seq; 
INSERT INTO [permission] ([permissionID], [description]) VALUES (@current_permission_seq, 'change asset');


DECLARE @current_employee_seq DECIMAL(12);
DECLARE @current_distribution_seq DECIMAL(12);
-- Insert two managers for different department
-- Get permission to keep and query the asset
SET @current_employee_seq = NEXT VALUE FOR employee_seq; 
INSERT INTO [employee] ([employeeID], [gender], [first_name], [last_name], [phone]) 
VALUES (@current_employee_seq, 'male', 'Evans', 'Hunk', '16248735');
INSERT INTO [manager] ([employeeID], [department]) 
VALUES (@current_employee_seq, 'marketing');
SET @current_distribution_seq = NEXT VALUE FOR distribution_seq; 
INSERT INTO [distribution] ([distributionID], [employeeID], [permissionID], [start_date], [end_date]) 
VALUES (@current_distribution_seq, @current_employee_seq, 2, '2022-08-01', NULL);
SET @current_distribution_seq = NEXT VALUE FOR distribution_seq; 
INSERT INTO [distribution] ([distributionID], [employeeID], [permissionID], [start_date], [end_date]) 
VALUES (@current_distribution_seq, @current_employee_seq, 3, '2022-08-01', NULL);

SET @current_employee_seq = NEXT VALUE FOR employee_seq; 
INSERT INTO [employee] ([employeeID], [gender], [first_name], [last_name], [phone]) 
VALUES (@current_employee_seq, 'female', 'Mitchell', 'Oliver', '15947862');
INSERT INTO [manager] ([employeeID], [department]) 
VALUES (@current_employee_seq, 'personnel');
SET @current_distribution_seq = NEXT VALUE FOR distribution_seq; 
INSERT INTO [distribution] ([distributionID], [employeeID], [permissionID], [start_date], [end_date]) 
VALUES (@current_distribution_seq, @current_employee_seq, 2, '2022-08-01', NULL);
SET @current_distribution_seq = NEXT VALUE FOR distribution_seq; 
INSERT INTO [distribution] ([distributionID], [employeeID], [permissionID], [start_date], [end_date]) 
VALUES (@current_distribution_seq, @current_employee_seq, 3, '2022-08-01', NULL);

-- Insert three saleman to be responsible for queens area
-- Get permission to use the asset

SET @current_employee_seq = NEXT VALUE FOR employee_seq; 
INSERT INTO [employee] ([employeeID], [gender], [first_name], [last_name], [phone]) 
VALUES (@current_employee_seq, 'male', 'Davis', 'Abel', '14789635');
INSERT INTO [saleman] ([employeeID], [area]) 
VALUES (@current_employee_seq, 'queens');
SET @current_distribution_seq = NEXT VALUE FOR distribution_seq; 
INSERT INTO [distribution] ([distributionID], [employeeID], [permissionID], [start_date], [end_date]) 
VALUES (@current_distribution_seq, @current_employee_seq, 1, '2022-08-06', NULL);

SET @current_employee_seq = NEXT VALUE FOR employee_seq; 
INSERT INTO [employee] ([employeeID], [gender], [first_name], [last_name], [phone]) 
VALUES (@current_employee_seq, 'male', 'Miller', 'Bert', '14785235');
INSERT INTO [saleman] ([employeeID], [area]) 
VALUES (@current_employee_seq, 'queens');
SET @current_distribution_seq = NEXT VALUE FOR distribution_seq; 
INSERT INTO [distribution] ([distributionID], [employeeID], [permissionID], [start_date], [end_date]) 
VALUES (@current_distribution_seq, @current_employee_seq, 1, '2022-08-06', NULL);

SET @current_employee_seq = NEXT VALUE FOR employee_seq; 
INSERT INTO [employee] ([employeeID], [gender], [first_name], [last_name], [phone]) 
VALUES (@current_employee_seq, 'female', 'Smith', 'Carl', '14715937');
INSERT INTO [saleman] ([employeeID], [area]) 
VALUES (@current_employee_seq, 'queens');
SET @current_distribution_seq = NEXT VALUE FOR distribution_seq; 
INSERT INTO [distribution] ([distributionID], [employeeID], [permissionID], [start_date], [end_date]) 
VALUES (@current_distribution_seq, @current_employee_seq, 1, '2022-08-06', NULL);

-- Insert two saleman to be responsible for resort area
-- Get no permission to use the asset

SET @current_employee_seq = NEXT VALUE FOR employee_seq; 
INSERT INTO [employee] ([employeeID], [gender], [first_name], [last_name], [phone]) 
VALUES (@current_employee_seq, 'male', 'Johnson', 'Edgar', '15945687');
INSERT INTO [saleman] ([employeeID], [area]) 
VALUES (@current_employee_seq, 'resort');

SET @current_employee_seq = NEXT VALUE FOR employee_seq; 
INSERT INTO [employee] ([employeeID], [gender], [first_name], [last_name], [phone]) 
VALUES (@current_employee_seq, 'female', 'White', 'Caspar', '16548765');
INSERT INTO [saleman] ([employeeID], [area]) 
VALUES (@current_employee_seq, 'resort');

-- Insert two finacial person with different level
-- Get permission to query or change the asset.
SET @current_employee_seq = NEXT VALUE FOR employee_seq; 
INSERT INTO [employee] ([employeeID], [gender], [first_name], [last_name], [phone]) 
VALUES (@current_employee_seq, 'female', 'Lewis', 'Glen', '15874568');
INSERT INTO [finacial] ([employeeID], [level]) 
VALUES (@current_employee_seq, 'senior');
SET @current_distribution_seq = NEXT VALUE FOR distribution_seq; 
INSERT INTO [distribution] ([distributionID], [employeeID], [permissionID], [start_date], [end_date]) 
VALUES (@current_distribution_seq, @current_employee_seq, 3, '2022-08-05', NULL);


SET @current_employee_seq = NEXT VALUE FOR employee_seq; 
INSERT INTO [employee] ([employeeID], [gender], [first_name], [last_name], [phone]) 
VALUES (@current_employee_seq, 'male', 'Hill', 'Henry', '14732569');
INSERT INTO [finacial] ([employeeID], [level]) 
VALUES (@current_employee_seq, 'primary');
SET @current_distribution_seq = NEXT VALUE FOR distribution_seq; 
INSERT INTO [distribution] ([distributionID], [employeeID], [permissionID], [start_date], [end_date]) 
VALUES (@current_distribution_seq, @current_employee_seq, 3, '2022-08-05', NULL);
SET @current_distribution_seq = NEXT VALUE FOR distribution_seq; 
INSERT INTO [distribution] ([distributionID], [employeeID], [permissionID], [start_date], [end_date]) 
VALUES (@current_distribution_seq, @current_employee_seq, 4, '2022-08-05', NULL);

-- -- Creating the location information
DECLARE @current_location_seq DECIMAL(12);
SET @current_location_seq = NEXT VALUE FOR location_seq; 
INSERT INTO [location] ([locationID], [addresses]) VALUES (@current_location_seq, 'default');
SET @current_location_seq = NEXT VALUE FOR location_seq; 
INSERT INTO [location] ([locationID], [addresses]) VALUES (@current_location_seq, 'office');
SET @current_location_seq = NEXT VALUE FOR location_seq; 
INSERT INTO [location] ([locationID], [addresses]) VALUES (@current_location_seq, 'warehouse');
SET @current_location_seq = NEXT VALUE FOR location_seq; 
INSERT INTO [location] ([locationID], [addresses]) VALUES (@current_location_seq, 'meeting room');
SET @current_location_seq = NEXT VALUE FOR location_seq; 
INSERT INTO [location] ([locationID], [addresses]) VALUES (@current_location_seq, 'activity room');

-- -- Asset data is generated through the stored procedure
EXECUTE asset_import 'Computer(Alien)','2019-05-08',1999.95,10;
EXECUTE asset_import 'Desk lamp(ADD)','2019-05-10',85.50,12;
EXECUTE asset_import 'Tent(Camel)','2019-05-12',125.25,5;
EXECUTE asset_import 'Desk(MBX)','2019-05-18',69.98,8;
EXECUTE asset_import 'Chair(MBX)','2019-06-08',33.33,22;
EXECUTE asset_import 'Bookcase(XYG)','2019-06-09',70.00,5;
EXECUTE asset_import 'Air conditioner(Haier)','2019-06-25',500.00,6;
EXECUTE asset_import 'Printer(Haier)','2019-07-08',125.88,8;
EXECUTE asset_import 'Electric cars(Ford)','2020-03-12',12580.00,2;
EXECUTE asset_import 'Chair(MBX)','2020-05-15',33.33,22;
EXECUTE asset_import 'Bookcase(XYG)','2020-06-18',71.00,5;
EXECUTE asset_import 'Air conditioner(Haier)','2020-06-20',510.00,6;
EXECUTE asset_import 'Printer(Haier)','2020-08-15',128.88,8;
EXECUTE asset_import 'Electric cars(Ford)','2020-12-08',11000.00,4;
EXECUTE asset_import 'Computer(Alien)','2021-01-11',1980.90,15;
EXECUTE asset_import 'Desk lamp(ADD)','2021-03-08',80.50,6;
EXECUTE asset_import 'Tent(Camel)','2021-07-15',125.25,8;
EXECUTE asset_import 'Desk(MBX)','2021-09-09',65.50,11;
EXECUTE asset_import 'Chair(MBX)','2022-01-05',39.00,11;
EXECUTE asset_import 'Bookcase(XYG)','2022-02-22',75.00,6;
EXECUTE asset_import 'Air conditioner(Haier)','2022-02-25',510.00,7;
EXECUTE asset_import 'Computer(Alien)','2022-03-06',1990.95,9;
EXECUTE asset_import 'Desk lamp(ADD)','2022-05-11',89.50,18;
EXECUTE asset_import 'Tent(Camel)','2022-06-20',120.25,6;
EXECUTE asset_import 'Desk(MBX)','2022-07-19',65.98,12;
-- 

-- 
-- -- Set administrator for assets
DECLARE @current_administrator_seq DECIMAL(12);
SET @current_administrator_seq = NEXT VALUE FOR administrator_seq; 
INSERT INTO [administrator] ([administratorID], [employeeID], [assetID], [start_date], [end_date]) 
VALUES (@current_administrator_seq, 1, 1, '2019-05-10', NULL);
SET @current_administrator_seq = NEXT VALUE FOR administrator_seq; 
INSERT INTO [administrator] ([administratorID], [employeeID], [assetID], [start_date], [end_date]) 
VALUES (@current_administrator_seq, 1, 2, '2019-05-12', NULL);
SET @current_administrator_seq = NEXT VALUE FOR administrator_seq; 
INSERT INTO [administrator] ([administratorID], [employeeID], [assetID], [start_date], [end_date]) 
VALUES (@current_administrator_seq, 1, 3, '2019-05-18', NULL);
SET @current_administrator_seq = NEXT VALUE FOR administrator_seq; 
INSERT INTO [administrator] ([administratorID], [employeeID], [assetID], [start_date], [end_date]) 
VALUES (@current_administrator_seq, 1, 4, '2019-05-25', NULL);
SET @current_administrator_seq = NEXT VALUE FOR administrator_seq; 
INSERT INTO [administrator] ([administratorID], [employeeID], [assetID], [start_date], [end_date]) 
VALUES (@current_administrator_seq, 2, 5, '2020-05-25', NULL);
SET @current_administrator_seq = NEXT VALUE FOR administrator_seq; 
INSERT INTO [administrator] ([administratorID], [employeeID], [assetID], [start_date], [end_date]) 
VALUES (@current_administrator_seq, 2, 6, '2020-06-06', NULL);
SET @current_administrator_seq = NEXT VALUE FOR administrator_seq; 
INSERT INTO [administrator] ([administratorID], [employeeID], [assetID], [start_date], [end_date]) 
VALUES (@current_administrator_seq, 2, 7, '2020-06-06', NULL);
SET @current_administrator_seq = NEXT VALUE FOR administrator_seq; 
INSERT INTO [administrator] ([administratorID], [employeeID], [assetID], [start_date], [end_date]) 
VALUES (@current_administrator_seq, 2, 8, '2020-06-06', NULL);
SET @current_administrator_seq = NEXT VALUE FOR administrator_seq; 
INSERT INTO [administrator] ([administratorID], [employeeID], [assetID], [start_date], [end_date]) 
VALUES (@current_administrator_seq, 2, 9, '2020-06-06', NULL);
 
-- Set user of asset by stored procedure
EXECUTE use_asset 4,1,'2022-05-01';
EXECUTE use_asset 4,2,'2022-05-02';
EXECUTE use_asset 4,9,'2022-05-03';
EXECUTE use_asset 4,3,'2022-05-03';
EXECUTE use_asset 4,4,'2022-05-05';
EXECUTE use_asset 5,5,'2022-05-05';
EXECUTE use_asset 5,6,'2022-05-06';
EXECUTE use_asset 5,7,'2022-05-05';
EXECUTE use_asset 5,8,'2022-05-05';
EXECUTE use_asset 3,1,'2022-06-03';
EXECUTE use_asset 4,2,'2022-06-05';
EXECUTE use_asset 4,9,'2022-06-06';
EXECUTE use_asset 4,3,'2022-06-06';
EXECUTE use_asset 4,4,'2022-06-08';
EXECUTE use_asset 4,5,'2022-06-08';
EXECUTE use_asset 4,6,'2022-06-09';
EXECUTE use_asset 5,7,'2022-06-12';
EXECUTE use_asset 5,8,'2022-06-15';
EXECUTE use_asset 3,1,'2022-07-01';
EXECUTE use_asset 3,2,'2022-07-02';
EXECUTE use_asset 3,9,'2022-07-03';
EXECUTE use_asset 4,3,'2022-07-03';
EXECUTE use_asset 4,4,'2022-07-05';
EXECUTE use_asset 4,5,'2022-07-05';
EXECUTE use_asset 5,6,'2022-07-06';
EXECUTE use_asset 5,7,'2022-07-07';
EXECUTE use_asset 5,8,'2022-07-07';
EXECUTE use_asset 3,1,'2022-08-01';
EXECUTE use_asset 3,2,'2022-08-02';
EXECUTE use_asset 3,9,'2022-08-03';
EXECUTE use_asset 4,3,'2022-08-03';
EXECUTE use_asset 4,4,'2022-08-05';
EXECUTE use_asset 4,5,'2022-08-05';
EXECUTE use_asset 5,6,'2022-08-06';
EXECUTE use_asset 5,7,'2022-08-07';
EXECUTE use_asset 5,8,'2022-08-07';