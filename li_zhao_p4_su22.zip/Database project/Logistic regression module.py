import pandas as pd
from matplotlib import pyplot as plt
import matplotlib as mpl
import seaborn as sns
import numpy as np
import statsmodels.api as sm
import statsmodels.stats.api as sms
import statsmodels.formula.api as smf
import scipy
import pymysql

db_conn = pymysql.connect(
    host='localhost',
    port=3306,
    user='root',
    password='123',
    database='asset_management',
    charset='utf8'
)

sql = "select * from asset_aggregate"
my_sasset = pd.read_sql(sql, con=db_conn)

train_data = my_sasset.sample(frac=0.8)
test_data = my_sasset[~my_sasset.index.isin(train_data.index)]
select_var = sm.add_constant(train_data[['use_time', 'material', 'price', 'maintenance ', 'service_life']])
logit = sm.Logit(train_data['asset_status'], select_var)
result = logit.fit()
result.summary()

select_var = test_data[['use_time', 'material', 'price', 'maintenance ', 'service_life']]
probValue = result_2.predict(select_var)
predictedValue = probValue.apply(lambda x: 1 if x >= 0.5 else 0)

compare_result = pd.DataFrame(predictedValue, columns=['predict'])
compare_result['original'] = test_data['asset_status']
compare_result['judge'] = 0

compare_result['judge'] = compare_result.apply(lambda x: 'TP' if x[0] == 1 and x[1] == 1 and x[2] == 0 else x[2],
                                               axis=1)
compare_result['judge'] = compare_result.apply(lambda x: 'FP' if x[0] == 1 and x[1] == 0 and x[2] == 0 else x[2],
                                               axis=1)
compare_result['judge'] = compare_result.apply(lambda x: 'TN' if x[0] == 0 and x[1] == 0 and x[2] == 0 else x[2],
                                               axis=1)
compare_result['judge'] = compare_result.apply(lambda x: 'FN' if x[0] == 0 and x[1] == 1 and x[2] == 0 else x[2],
                                               axis=1)

TP = len(compare_result[compare_result['judge'] == 'TP'])
FP = len(compare_result[compare_result['judge'] == 'FP'])
TN = len(compare_result[compare_result['judge'] == 'TN'])
FN = len(compare_result[compare_result['judge'] == 'FN'])

display(compare_result)
print(f"TP:{TP}\nFP:{FP}\nTN:{TN}\nFN:{FN}\n")

from sklearn.metrics import precision_score, recall_score, f1_score

precision = precision_score(compare_result['original'], compare_result['predict'], average='binary')
recall = recall_score(compare_result['original'], compare_result['predict'], average='binary')
f1_score = f1_score(compare_result['original'], compare_result['predict'], average='binary')

print(f'Precision:{precision}\nRecall:{recall}\nF1 score:{f1_score}')

from sklearn.metrics import roc_curve, auc, mean_squared_error, accuracy_score
import math

fpr, tpr, thresholds = roc_curve(compare_result['original'], probValue)
plt.hist(fpr, color='steelblue')
plt.title('Fpr')
plt.show()
fpr, tpr, thresholds = roc_curve(compare_result['original'], probValue)
plt.hist(tpr, color='steelblue')
plt.title('Tpr')
plt.show()
fpr, tpr, thresholds = roc_curve(compare_result['original'], probValue)
plt.hist(thresholds, color='steelblue')
plt.title('Thresholds')
plt.show()

roc_auc = auc(fpr, tpr)
# print(roc_auc)
plt.figure()
plt.plot(fpr, tpr, color='darkorange', lw=2, label='ROC curve (area = %0.2f)' % roc_auc)
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([-0.1, 1.05])
plt.ylim([-0.1, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Tomatometer Status AOC')
plt.legend(loc="lower right")
plt.show()

print('results are RMSE, accuracy, ROC')

print(math.sqrt(mean_squared_error(compare_result['original'], probValue)),
      accuracy_score(compare_result['original'], compare_result['predict']), roc_auc)
