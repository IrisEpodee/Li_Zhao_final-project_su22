--1st: Quary all assets used in queens area for its total number and price.
SELECT
	COUNT(asset.assetID) AS assets_number, 
	SUM(asset.[total price]) AS assets_price
FROM
	dbo.saleman
	INNER JOIN
	dbo.employee
	ON 
		saleman.employeeID = employee.employeeID
	INNER JOIN
	dbo.[user]
	ON 
		employee.employeeID = [user].employeeID
	INNER JOIN
	dbo.asset
	ON 
		[user].assetID = asset.assetID
WHERE
	saleman.area = 'queens';
	
-- 2st:Find out the information about the manager who manages the 'Computer(Alien)', and the department in charge
SELECT
	employee.first_name, 
	employee.last_name, 
	employee.phone, 
	manager.department
FROM
	dbo.administrator
	INNER JOIN
	dbo.asset
	ON 
		administrator.assetID = asset.assetID
	INNER JOIN
	dbo.employee
	ON 
		administrator.employeeID = employee.employeeID
	INNER JOIN
	dbo.manager
	ON 
		employee.employeeID = manager.employeeID
WHERE
	asset.name = 'Computer(Alien)';
	
-- 3st:All employees using assets from 2021 to the present, and the number of assets they are using
SELECT
	employee.first_name, 
	employee.last_name, 
	COUNT(asset.assetID) AS asset_number
FROM
	dbo.employee
	INNER JOIN
	dbo.[user]
	ON 
		employee.employeeID = [user].employeeID
	INNER JOIN
	dbo.asset
	ON 
		[user].assetID = asset.assetID
WHERE
	[user].start_date >= '2021-01-01' AND
	[user].start_date <= '2022-08-10'
GROUP BY
	employee.first_name, 
	employee.last_name