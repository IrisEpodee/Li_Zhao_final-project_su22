-- --TABLES
CREATE TABLE [dbo].[accounting] (
  [accountingID] decimal(12)  NOT NULL PRIMARY KEY,
  [assetID] decimal(12)  NOT NULL,
  [name] varchar(50)  NOT NULL,
  [purchase date] date  NOT NULL,
  [price] decimal(20,4)  NOT NULL,
  [number] decimal(20,4)  NOT NULL
);
GO
CREATE TABLE [dbo].[administrator] (
  [administratorID] decimal(12)  NOT NULL PRIMARY KEY,
  [employeeID] decimal(12)  NOT NULL,
  [assetID] decimal(12)  NOT NULL,
  [start_date] date  NOT NULL,
  [end_date] date  NULL
);

CREATE TABLE [dbo].[asset] (
  [assetID] decimal(12)  NOT NULL PRIMARY KEY,
  [producerID] decimal(12)  NULL,
  [locationID] decimal(12)  NOT NULL,
  [name] varchar(50) NOT NULL,
  [total price] decimal(20,4)  NOT NULL,
  [total number] decimal(20,4)  NOT NULL
);

CREATE TABLE [dbo].[contact] (
  [contactID] decimal(12)  NOT NULL PRIMARY KEY,
  [name] varchar(50) NOT NULL,
  [phone] varchar(50)  NOT NULL
);

CREATE TABLE [dbo].[distribution] (
  [distributionID] decimal(12)  NOT NULL PRIMARY KEY,
  [employeeID] decimal(12)  NOT NULL,
  [permissionID] decimal(12)  NOT NULL,
  [start_date] date  NOT NULL,
  [end_date] date  NULL
);

CREATE TABLE [dbo].[employee] (
  [employeeID] decimal(12)  NOT NULL PRIMARY KEY,
  [gender] varchar(6) NOT NULL,
  [first_name] varchar(50) NOT NULL,
  [last_name] varchar(50)  NOT NULL,
  [phone] varchar(20)  NOT NULL
);

CREATE TABLE [dbo].[finacial] (
  [employeeID] decimal(12)  NOT NULL PRIMARY KEY,
  [level] varchar(50) NOT NULL
);

CREATE TABLE [dbo].[implement] (
  [implementID] decimal(12)  NOT NULL PRIMARY KEY,
  [inventoryID] decimal(12)  NOT NULL,
  [assetID] decimal(12)  NOT NULL,
  [actual number] decimal(20,4)  NOT NULL,
  [actual state] decimal(20,4)  NOT NULL,
  [start_date] date  NOT NULL,
  [end_date] date  NOT NULL
);

CREATE TABLE [dbo].[inside] (
  [locationID] decimal(12)  NOT NULL PRIMARY KEY,
  [floor] varchar(50) NULL
);

CREATE TABLE [dbo].[inventory] (
  [inventoryID] decimal(12)  NOT NULL PRIMARY KEY, 
  [total time] decimal(20,4)  NOT NULL
);

CREATE TABLE [dbo].[location] (
  [locationID] decimal(12)  NOT NULL PRIMARY KEY,
  [addresses] varchar(50) NOT NULL
);

CREATE TABLE [dbo].[manager] (
  [employeeID] decimal(12)  NOT NULL PRIMARY KEY,
  [department] varchar(50) NOT NULL
);

CREATE TABLE [dbo].[outside] (
  [locationID] decimal(12)  NOT NULL PRIMARY KEY,
  [contactID] decimal(12)  NOT NULL,
  [relationship] varchar(100) NOT NULL
);

CREATE TABLE [dbo].[permission] (
  [permissionID] decimal(12)  NOT NULL PRIMARY KEY,
  [description] varchar(50) NOT NULL
);

CREATE TABLE [dbo].[producer] (
  [producerID] decimal(12)  NOT NULL PRIMARY KEY,
  [name] varchar(50) NOT NULL,
  [phone] varchar(50) NOT NULL
);
CREATE TABLE [dbo].[saleman] (
  [employeeID] decimal(12)  NOT NULL PRIMARY KEY,
  [area] varchar(50) NOT NULL
);
CREATE TABLE [dbo].[user] (
  [userID] decimal(12)  NOT NULL PRIMARY KEY,
  [employeeID] decimal(12)  NOT NULL,
  [assetID] decimal(12)  NOT NULL,
  [start_date] date  NOT NULL,
  [end_date] date  NULL
);
ALTER TABLE [dbo].[accounting] ADD FOREIGN KEY ([assetID]) REFERENCES [dbo].[asset] ([assetID]);
ALTER TABLE [dbo].[administrator] ADD FOREIGN KEY ([employeeID]) REFERENCES [dbo].[employee] ([employeeID]);
ALTER TABLE [dbo].[administrator] ADD FOREIGN KEY ([assetID]) REFERENCES [dbo].[asset] ([assetID]);
ALTER TABLE [dbo].[asset] ADD FOREIGN KEY ([producerID]) REFERENCES [dbo].[producer] ([producerID]);
ALTER TABLE [dbo].[asset] ADD FOREIGN KEY ([locationID]) REFERENCES [dbo].[location] ([locationID]);
ALTER TABLE [dbo].[distribution] ADD FOREIGN KEY ([employeeID]) REFERENCES [dbo].[employee] ([employeeID]);
ALTER TABLE [dbo].[distribution] ADD FOREIGN KEY ([permissionID]) REFERENCES [dbo].[permission] ([permissionID]);
ALTER TABLE [dbo].[finacial] ADD FOREIGN KEY ([employeeID]) REFERENCES [dbo].[employee] ([employeeID]);
ALTER TABLE [dbo].[implement] ADD FOREIGN KEY ([inventoryID]) REFERENCES [dbo].[inventory] ([inventoryID]);
ALTER TABLE [dbo].[implement] ADD FOREIGN KEY ([assetID]) REFERENCES [dbo].[asset] ([assetID]);
ALTER TABLE [dbo].[inside] ADD FOREIGN KEY ([locationID]) REFERENCES [dbo].[location] ([locationID]);
ALTER TABLE [dbo].[manager] ADD FOREIGN KEY ([employeeID]) REFERENCES [dbo].[employee] ([employeeID]);
ALTER TABLE [dbo].[outside] ADD FOREIGN KEY ([contactID]) REFERENCES [dbo].[contact] ([contactID]);
ALTER TABLE [dbo].[saleman] ADD FOREIGN KEY ([employeeID]) REFERENCES [dbo].[employee] ([employeeID]);
ALTER TABLE [dbo].[user] ADD FOREIGN KEY ([employeeID]) REFERENCES [dbo].[employee] ([employeeID]);
ALTER TABLE [dbo].[user] ADD FOREIGN KEY ([assetID]) REFERENCES [dbo].[asset] ([assetID]);
--SEQUENCES
CREATE SEQUENCE employee_seq START WITH 1
CREATE SEQUENCE distribution_seq START WITH 1
CREATE SEQUENCE permission_seq START WITH 1
CREATE SEQUENCE user_seq START WITH 1
CREATE SEQUENCE administrator_seq START WITH 1
CREATE SEQUENCE accounting_seq START WITH 1
CREATE SEQUENCE asset_seq START WITH 1
CREATE SEQUENCE implement_seq START WITH 1
CREATE SEQUENCE producer_seq START WITH 1
CREATE SEQUENCE inventory_seq START WITH 1
CREATE SEQUENCE location_seq START WITH 1
CREATE SEQUENCE inside_seq START WITH 1
CREATE SEQUENCE outside_seq START WITH 1
CREATE SEQUENCE contact_seq START WITH 1

--INDEXES
CREATE UNIQUE INDEX accounting_index
ON accounting(accountingID)

CREATE UNIQUE INDEX administrator_index
ON administrator(administratorID)
CREATE INDEX administrator_employee_index
ON administrator(employeeID)
CREATE INDEX administrator_asset_index
ON administrator(assetID)

CREATE UNIQUE INDEX asset_index
ON asset(assetID)
CREATE INDEX asset_producer_index
ON asset(producerID)
CREATE INDEX asset_location_index
ON asset(locationID)
CREATE INDEX asset_name_index
ON asset(name)

CREATE UNIQUE INDEX contact_index
ON contact(contactID)

CREATE UNIQUE INDEX distribution_index
ON distribution(distributionID)
CREATE INDEX distribution_employee_index
ON distribution(employeeID)
CREATE INDEX distribution_permission_index
ON distribution(permissionID)

CREATE UNIQUE INDEX employee_index
ON employee(employeeID)
CREATE INDEX employee_fname_index
ON employee(first_name)
CREATE INDEX employee_lname_index
ON employee(last_name)

CREATE UNIQUE INDEX finacial_index
ON finacial(employeeID)

CREATE UNIQUE INDEX implement_index
ON implement(implementID)
CREATE INDEX implement_inventory_index
ON implement(inventoryID)
CREATE INDEX implement_asset_index
ON implement(assetID)
CREATE INDEX implement_state_index
ON implement([actual state])

CREATE UNIQUE INDEX inside_index
ON inside(locationID)

CREATE UNIQUE INDEX inventory_index
ON inventory(inventoryID)

CREATE UNIQUE INDEX location_index
ON location(locationID)

CREATE UNIQUE INDEX manager_index
ON manager(employeeID)

CREATE UNIQUE INDEX outside_index
ON outside(locationID)

CREATE UNIQUE INDEX permission_index
ON permission(permissionID)

CREATE UNIQUE INDEX producer_index
ON producer(producerID)

CREATE UNIQUE INDEX saleman_index
ON saleman(employeeID)

CREATE UNIQUE INDEX user_index
ON [user](userID)
CREATE INDEX user_employee_index
ON [user](employeeID)
CREATE INDEX user_asset_index
ON [user](assetID)
CREATE INDEX user_start_index
ON [user](start_date)
CREATE INDEX user_end_index
ON [user](end_date)

CREATE INDEX user_employee_index
ON [user](employeeID)

CREATE INDEX user_asset_index
ON [user](assetID)