CREATE TABLE `ManagerContract` (
	`SitCode`	varchar NOT NULL,
	`IssueDate`	varchar,
	`State`	date,
	PRIMARY KEY(SitCode)
);

CREATE TABLE `Customer` (
	`CustomerID`	INTEGER NOT NULL,
	`CustomerFirstName`	varchar,
	`CustomerLastName`	TEXT,
	`CustDOB`	date,
	`CustomerSuffix`	varchar,
	`CustomerMiddleInitial`	varchar,
	PRIMARY KEY(CustomerID)
);

CREATE TABLE `CustomerRelation` (
	`CustomerID`	INTEGER NOT NULL,
	`RelationID`	INTEGER NOT NULL,
	`Relation`	TEXT,
	FOREIGN KEY(CustomerID) REFERENCES Customer(CustomerID),
	FOREIGN KEY(RelationID) REFERENCES Customer(CustomerID)
);

CREATE TABLE `Contract` (
	`ContractNumber`	INTEGER NOT NULL,
	`SeriesName`	varchar,
	PRIMARY KEY(ContractNumber)
);

CREATE TABLE `ContractBenifit` (
	`ContractNumber`	INTEGER NOT NULL,
	`SeriesName`	varchar,
	`PlanName`	INTEGER,
	`RiderName`	varchar,
	FOREIGN KEY(ContractNumber) REFERENCES Contract(ContractNumber)
);

CREATE TABLE `ContractPremium` (
	`PremiumCode`	INTEGER NOT NULL,
	`ContractNumber`	INTEGER NOT NULL,
	`SeriesName`	varchar,
	`PlanName`	varchar,
	`RiderName`	varchar,
	PRIMARY KEY(PremiumCode),
	FOREIGN KEY(ContractNumber) REFERENCES Contract(ContractNumber)
);

CREATE TABLE `Associate` (
	`AssocID`	INTEGER NOT NULL,
	`AssocFirstName`	varchar,
	`AssocLastName`	varchar,
	`AssocDOB`	date,
	`AssocSuffix`	varchar,
	`AssocMiddleInital`	varchar,
	PRIMARY KEY(AssocID)
);

CREATE TABLE `AssociateRelation` (
	`AssocID`	INTEGER NOT NULL,
	`RelationID`	INTEGER NOT NULL,
	`Relation`	TEXT,
	FOREIGN KEY(AssocID) REFERENCES Associate(AssocID),
	FOREIGN KEY(RelationID) REFERENCES Associate(AssocID)
);

CREATE TABLE `Account` (
	`AccountID`	INTEGER NOT NULL,
	`AccountName`	varchar,
	`AccountName2`	varchar,
	`LocationZIP`	varchar,
	`LocationAddress1`	varchar,
	`LocationAddress2`	varchar,
	`LocationCity`	varchar,
	`LocationState`	varchar,
	PRIMARY KEY(AccountID)
);

CREATE TABLE `AccountRelation` (
	`AccountName`	varchar,
	`RelationName`	varchar,
	`Relation`	TEXT,
	`AccountID`	INTEGER NOT NULL,
	`RelationID`	INTEGER NOT NULL,
	FOREIGN KEY(AccountID) REFERENCES Account(AccountID),
	FOREIGN KEY(RelationID) REFERENCES Account(AccountID)
);

CREATE TABLE `Company` (
	`CompanyCode`	varchar,
	`CompanyName`	TEXT,
	PRIMARY KEY(CompanyCode)
);

CREATE TABLE `AccountLegacyAlias` (
	`AliasID`	INTEGER,
	`AliasSource`	varchar,
	`AccountName`	varchar,
	`AccountName2`	varchar,
	`LocationZIP`	varchar,
	`LocationState`	varchar,
	`LocationCity`	varchar,
	`CompanyCode`	varchar,
	`LocationAddress1`	varchar,
	`LocationAddress2`	varchar
);

CREATE TABLE `AccountMember` (
	`StartDate`	date,
	`AccountID`	INTEGER,
	`AccountName1`	varchar,
	`AccountName2`	varchar,
	`CustomerID`	INTEGER,
	`LocationZIP`	INTEGER,
	`LocationAddress1`	INTEGER,
	`LocationAddress2`	varchar,
	`LocationCity`	varchar,
	`LocationState`	varchar
);

CREATE TABLE `BillingAccount` (
	`BAcctName`	varchar,
	`BAcctName2`	varchar,
	`BAcctAddress`	varchar,
	`BAcctAddress2`	varchar,
	`BAcctZip`	varchar,
	`BAcctState`	varchar,
	`BAcctCity`	varchar
);

CREATE TABLE `AccountAdmin` (
	`AdminID`	INTEGER NOT NULL,
	`AdminCity`	varchar,
	`AdminState`	varchar,
	`AdminAddress1`	varchar,
	`AdminAddress2`	varchar,
	`AdminZip`	varchar,
	`AdminFirstName`	varchar,
	`AdminLastName`	varchar,
	`AdminSuffix`	varchar,
	`AdminMiddleInitial`	varchar,
	PRIMARY KEY(AdminID)
);
